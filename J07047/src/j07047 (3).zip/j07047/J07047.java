/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package j07047;

import java.io.FileNotFoundException;
import java.io.*;
import java.lang.reflect.Array;
import java.text.ParseException;
import  java.util.*;
/**
 *
 * @author admin
 */
public class J07047 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws FileNotFoundException,ParseException{
        // TODO code application logic here
        File f=new File("DATA.in");
        Scanner sc=new Scanner(f);
        List<Phong> list1=new ArrayList<>();
        int t=Integer.parseInt(sc.nextLine());
        while(t-->0){
            String[] ss=sc.nextLine().split("\\s+");
            String id=ss[0];
            String name=ss[1];
            int dongia=Integer.parseInt(ss[2]);
            double phiphucvu=Double.parseDouble(ss[3]);
            list1.add(new Phong(id, name, dongia, phiphucvu));
        }
        t=Integer.parseInt(sc.nextLine());
        List<KhachHang> list2=new ArrayList<>();
        while(t-->0){
            String nameString=sc.nextLine();
            String idP=sc.nextLine();
            String ngaydenString=sc.nextLine();
            String ngaydiString=sc.nextLine();
            for(Phong xPhong:list1){
                if(idP.substring(2,3).equals(xPhong.getId())){
                    list2.add(new KhachHang(nameString,idP,ngaydenString,ngaydiString,xPhong.getDongia(),xPhong.getPhiphucvu()));
                }
            }
        }
        list2.sort(new Comparator<KhachHang>() {
            @Override
            public int compare(KhachHang o1, KhachHang o2) {
              return Integer.compare(o2.getNgayO(),o1.getNgayO());
            }
        });
        for(KhachHang x:list2){
            System.out.println(x);
        }
    }
    
}
