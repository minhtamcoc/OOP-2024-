/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package j07047;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author admin
 */
public class KhachHang {
    static int idx=0;
    private String id;
    private String name;
    private String idP;
    private String ngayden;
    private String ngaydi;
    private int dongia;
    private double phiphucvu;
    private int ngayo;
    private double thanhtien;
    public KhachHang(String name, String idP, String ngayden, String ngaydi,int dongia,double phiphucvu)throws ParseException{
        idx++;
        this.id ="KH"+String.format("%02d",idx);
        this.name = name;
        this.idP = idP;
        this.ngayden = ngayden;
        this.ngaydi = ngaydi;
        this.dongia=dongia;
        this.phiphucvu=phiphucvu;
        SimpleDateFormat f=new SimpleDateFormat("dd/MM/yyyy");
        long time=f.parse(this.ngaydi).getTime()-f.parse(this.ngayden).getTime();
        this.ngayo=(int)time/86400000;
        int t=this.ngayo;
        if(t==0)t++;
        double tmp=this.dongia*t;
        double re1=this.phiphucvu*tmp;
        double re=tmp+re1;
        double res=0;
        if(this.ngayo>30){
            res=0.94*re;
        }
        else if(this.ngayo>=20){
            res=0.96*re;
        }
        else if(this.ngayo>=10){
            res=0.98*re;
        }
        else{
            res=re;
        }
        this.thanhtien = Math.round(res * 100.0) / 100.0;

    }
    public int getNgayO(){
        return ngayo;
    }
    public String toString(){
        return id+" "+name+" "+idP+" "+ngayo+" "+String.format("%.2f",thanhtien);
    }
}
